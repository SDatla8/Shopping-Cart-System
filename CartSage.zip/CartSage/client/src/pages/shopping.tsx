import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ShoppingCart, BarChart3 } from "lucide-react";
import FilterSidebar from "@/components/FilterSidebar";
import ProductGrid from "@/components/ProductGrid";
import { ProductFilter } from "@shared/schema";
import { useCart } from "@/hooks/useCart";
import { useLocation } from "wouter";

export default function ShoppingPage() {
  const [filters, setFilters] = useState<ProductFilter>({});
  const [sessionId] = useState(() => Math.random().toString(36).substring(7));
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [location, setLocation] = useLocation();
  const { cart: cartItems = [] } = useCart(sessionId);

  const cartItemCount = cartItems.reduce((sum: number, item: any) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Button
                onClick={() => setLocation("/")}
                variant="outline"
                size="sm"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Parse
              </Button>
              <h1 className="text-xl font-bold text-gray-900">Shopping</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button
                onClick={() => setLocation("/analytics")}
                variant="outline"
                className="flex items-center space-x-2"
              >
                <BarChart3 className="w-4 h-4" />
                <span>Analytics</span>
              </Button>
              
              <Button
                onClick={() => setIsCartOpen(true)}
                className="relative ai-gradient text-white px-6 py-2"
              >
                <ShoppingCart className="mr-2" size={18} />
                Cart
                {cartItemCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-6 h-6 flex items-center justify-center">
                    {cartItemCount}
                  </span>
                )}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters */}
          <aside className="lg:w-80">
            <FilterSidebar 
              filters={filters}
              onFiltersChange={setFilters}
            />
          </aside>
          
          {/* Products */}
          <main className="flex-1">
            <ProductGrid 
              filters={filters}
              sessionId={sessionId}
            />
          </main>
        </div>
      </div>

      {/* Cart sidebar placeholder - will be implemented */}
      {isCartOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50" onClick={() => setIsCartOpen(false)}>
          <div className="fixed right-0 top-0 h-full w-96 bg-white shadow-lg p-6">
            <h2 className="text-lg font-bold mb-4">Shopping Cart ({cartItemCount} items)</h2>
            <Button onClick={() => setIsCartOpen(false)}>Close</Button>
          </div>
        </div>
      )}
    </div>
  );
}